﻿angular.module('addcarApp.brandtemplates', ['ngRoute'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.
            when('/brand', {
                templateUrl: 'addcar/brand.html',
                controller: 'HomeCtrl'
            }).
            when('/model/:templateId', {
                templateUrl: 'addcar/model.html',
                controller: 'brandsCtrl'
            }).
            when('/details', {
                templateUrl: 'addcar/details.html',
                controller: 'detsCtrl'
            });
    }])

    .controller('HomeCtrl', ['$scope', '$http', function ($scope, $http) {
        $http.get('json/brands.json').success(function (data) {
            $scope.brandtemplates = data;
        });
    }])

    .controller('brandsCtrl', ['$scope', '$routeParams', '$http', '$filter', function ($scope, $routeParams, $http, $filter) {
        var templateId = $routeParams.templateId;
        $http.get('json/brands.json').success(function (data) {
            $scope.template = $filter('filter')(data, function (d) {
                return d.id == templateId;
            })[0];
            
        });
    }])

    .controller('detsCtrl', ['$scope', '$routeParams', '$http', '$filter', function ($scope, $routeParams, $http, $filter) {
        var x = localStorage.getItem("brand");
        document.getElementById("selBrand").innerHTML = x;
        document.getElementById("bttl").innerHTML = x;
        var y = localStorage.getItem("model");
        document.getElementById("selModel").innerHTML = y;
        document.getElementById("mttl").innerHTML = y;
    }])