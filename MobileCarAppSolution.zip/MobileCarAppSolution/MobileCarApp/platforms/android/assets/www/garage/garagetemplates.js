﻿angular.module('garageApp.garagetemplates', ['ngRoute'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.
            when('/home', {
                templateUrl: 'garage/garagehome.html',
                controller: 'HomeCtrl'
            }).
            when('/myCar/:templateId', {
                templateUrl: 'maintenance/task.html',
                controller: 'TaskDetailsCtrl'
            });
    }])

    .controller('HomeCtrl', ['$scope', '$http', function ($scope) {
        var gara = localStorage.getItem("garage");
        // rework with local store insead of json
        var tobe = '[' + gara + ']';
        var jsn = JSON.parse(tobe);
            $scope.tasktemplates = jsn;

    }])

    .controller('TaskDetailsCtrl', ['$scope', '$routeParams', '$http', '$filter', function ($scope, $routeParams, $http, $filter) {
        var templateId = $routeParams.templateId;
        $http.get('json/maintenance.json').success(function (data) {
            $scope.template = $filter('filter')(data, function (d) {
                return d.id == templateId;
            })[0];
            $scope.mainImage = $scope.template.images[0].name;
        });

        $scope.setImage = function (image) {
            $scope.mainImage = image.name;
        }

    }]);