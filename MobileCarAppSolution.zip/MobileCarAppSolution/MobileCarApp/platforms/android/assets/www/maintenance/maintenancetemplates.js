angular.module('maintenanceApp.tasktemplates',['ngRoute'])

.config(['$routeProvider', function($routeProvider){
    $routeProvider.
        when('/home', {
            templateUrl: 'maintenance/home.html',
            controller: 'HomeCtrl'
        }).
        when('/task/:templateId', {
            templateUrl: 'maintenance/task.html',
            controller: 'TaskDetailsCtrl'
        });
}])

.controller('HomeCtrl', ['$scope', '$http', function($scope, $http){
		$http.get('json/maintenance.json').success(function(data){
		$scope.tasktemplates = data;
	});
}])

.controller('TaskDetailsCtrl', ['$scope', '$routeParams', '$http', '$filter', function($scope, $routeParams, $http, $filter){
	var templateId = $routeParams.templateId;
    $http.get('json/maintenance.json').success(function(data){
		$scope.template = $filter('filter')(data, function(d){
			return d.id == templateId;
		})[0];
		$scope.mainImage = $scope.template.images[0].name;
	});

	$scope.setImage = function(image){
		$scope.mainImage = image.name;
	}
	
}]);