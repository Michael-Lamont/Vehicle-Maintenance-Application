﻿'use strict';

// Declare app level module which depends on views, and components
angular.module('addcarApp', [
    'ngRoute',
    //'projectApp.view1',
    //'projectApp.view2',
    'addcarApp.brandtemplates'
]).
    config(['$routeProvider', function ($routeProvider) {
        $routeProvider.otherwise({ redirectTo: '/brand' });
    }]);
