﻿function createItem(m) {
            localStorage.setItem("brand", document.getElementById("brandttl").innerHTML);
            localStorage.setItem("model", m.alt);
}

function makeobj() {
    var y = parseInt(document.getElementById("year").value);
    var l = document.getElementById("lic").value;
    var m = parseInt(document.getElementById("miles").value);
    var o = document.getElementById("oilc").value;
    var ofc = document.getElementById("oilfc").value;
    var t = document.getElementById("tirec").value;
    var ca = document.getElementById("cairfil").value;
    var ea = document.getElementById("eairfil").value;
    var f = document.getElementById("flsh").value;
    var col = document.getElementById("color").value;

    if (o == '') {
        if (m < 500) {
            o = 0;
        } else {
            o = m - 500;
        }
    }
    if (ofc == '') {
        if (m < 1000) {
            ofc = 0;
        } else {
            ofc = m - 1000;
        }
    }
    if (t == '') {
        if (m < 700) {
            t = 0;
        } else {
            t = m - 700;
        }
    }
    if (ca == '') {
        if (m < 2000) {
            ca = 0;
        } else {
            ca = m - 2000;
        }
    }
    if (ea == '') {
        if (m < 3000) {
            ea = 0;
        } else {
            ea = m - 3000;
        }      
    }
    if (f == '') {
        if (m < 3000) {
            f = 0;
        } else {
            f = m - 3000;
        }   
    }

    if (y > 1912  && y < 2020 && l != '' && m != '' && col != '') {
        var cid = parseInt(localStorage.getItem("carid"));
        var cr = "";
        var cars = localStorage.getItem("garage");
        if (cars != "") {
            cr = cars + ', ';
        }
        cr = cr + '{"id": "' + cid +
            '", "brand": "' + document.getElementById("selBrand").innerHTML +
            '", "model": "' + document.getElementById("selModel").innerHTML +
            '", "year": "' + y +
            '", "color": "' + col +
            '", "license": "' + l +
            '", "mileage": "' + m +
            '", "oil": "' + o +
            '", "oilFilter": "' + ofc +
            '", "tire": "' + t +
            '", "cabinair": "' + ca +
            '", "engineair": "' + ea +
            '", "coolant": "' + f +
            '"}';
        // find a way to save more than one car
        //document.getElementById("results").innerHTML = cr; 

        cid = cid + 1;
        localStorage.setItem("carid", cid);
        localStorage.setItem("garage", cr);
    }
    else
        return alert("Please be sure that you filled out Year, License, Color, and Milage");
} 