﻿

function myMap() {
    var latlong = { lat: 41.587800, lng: -87.475226 };
    var mapProp = {
        center: latlong,
        zoom: 17,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    var marker = new google.maps.Marker({
        position: latlong,
        map: map
    });
}

function mechan1() {
    var latlong = { lat: 41.588088, lng: -87.480451 };
    var mapProp = {
        center: latlong,
        zoom: 17,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    var marker = new google.maps.Marker({
        position: latlong,
        map: map
    });
}

function mechan2() {
    var latlong = { lat: 41.581334, lng: -87.480507 };
    var mapProp = {
        center: latlong,
        zoom: 17,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    var marker = new google.maps.Marker({
        position: latlong,
        map: map
    });
}

function mechan3() {
    var latlong = { lat: 41.581334, lng: -87.480589 };
    var mapProp = {
        center: latlong,
        zoom: 17,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    var marker = new google.maps.Marker({
        position: latlong,
        map: map
    });
}

function mechan4() {
    var latlong = { lat: 41.580831, lng: -87.480471 };
    var mapProp = {
        center: latlong,
        zoom: 17,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    var marker = new google.maps.Marker({
        position: latlong,
        map: map
    });
}

/*function getLocation() {
navigator.geolocation.watchPosition(showPosition);
}

function showPosition(position) {
    lat = position.coords.latitude;
    long = position.coords.longitude;
}*/