'use strict';

// Declare app level module which depends on views, and components
angular.module('maintenanceApp', [
  'ngRoute',
  //'projectApp.view1',
  //'projectApp.view2',
  'maintenanceApp.tasktemplates'
]).
config(['$routeProvider', function($routeProvider) {
  $routeProvider.otherwise({redirectTo: '/home'});
}]);
