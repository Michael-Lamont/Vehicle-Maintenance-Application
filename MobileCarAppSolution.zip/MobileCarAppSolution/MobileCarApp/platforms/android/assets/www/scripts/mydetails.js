﻿function getdets() {
    var cars = localStorage.getItem("garage");

    if (cars == "") {
        document.getElementById("myGe").innerHTML = "Please Add a car to view Your Garage";

    }
    else {
        var mycars = localStorage.getItem("garage");
        var car1, car2, car3, car4;
        car1 = mycars.substring(0, mycars.indexOf('}') + 1);
        localStorage.setItem("car01", car1);
        car1 = JSON.parse(car1);
        document.getElementById("carfi").innerHTML = car1.year + ' - ' + car1.brand + ' '+ car1.model + ' - ' + car1.license;
        mycars = mycars.substring(mycars.indexOf('}') + 2);
        if(mycars != ""){
            car2 = mycars.substring(0, mycars.indexOf('}') + 1);
            localStorage.setItem("car02", car2);
            car2 = JSON.parse(car2);
            document.getElementById("carse").innerHTML = car2.year + ' - ' + car2.brand + ' ' + car2.model + ' - ' + car2.license;
            mycars = mycars.substring(mycars.indexOf('}') + 2);
            if (mycars != "") {
                car3 = mycars.substring(0, mycars.indexOf('}') + 1);
                localStorage.setItem("car03", car3);
                car3 = JSON.parse(car3);
                document.getElementById("carth").innerHTML = car3.year + ' - ' + car3.brand + ' ' + car3.model + ' - ' + car3.license;
                mycars = mycars.substring(mycars.indexOf('}') + 2);
                if (mycars != "") {
                    car4 = mycars.substring(0, mycars.indexOf('}') + 1);
                    localStorage.setItem("car04", car4);
                    car4 = JSON.parse(car4);
                    document.getElementById("carfo").innerHTML = car4.year + ' - ' + car4.brand + ' '+ car4.model + ' - ' + car4.license;
                }

            }
        }
    }
}

function firstcar() {
    var car = localStorage.getItem("car01");
    var othercars ="";
    //set other cars with if statement repeatedly checking if car0x has a value or not and then load the temp garage appropriately
    if (localStorage.getItem("car02") != null){
        othercars = localStorage.getItem("car02") + ',';
        if (localStorage.getItem("car03") != null) {
            othercars = othercars + localStorage.getItem("car03") + ',';
            if (localStorage.getItem("car04") != null) {
                othercars = othercars + localStorage.getItem("car04") + ',';
            }
        }
    }

    localStorage.setItem("tempGarage", othercars);
    localStorage.setItem("selectedCar", car);
}

function secondcar() {
    var car = localStorage.getItem("car02");
    var othercars = "";
    if (localStorage.getItem("car01") != null) {
        othercars = localStorage.getItem("car01") + ',';
        if (localStorage.getItem("car03") != null) {
            othercars = othercars + localStorage.getItem("car03") + ',';
            if (localStorage.getItem("car04") != null) {
                othercars = othercars + localStorage.getItem("car04") + ',';
            }
        }
    }
    localStorage.setItem("tempGarage", othercars);
    localStorage.setItem("selectedCar", car);
}

function thirdcar() {
    var car = localStorage.getItem("car03");
    var othercars = "";
    if (localStorage.getItem("car01") != null) {
        othercars = localStorage.getItem("car01") + ',';
        if (localStorage.getItem("car02") != null) {
            othercars = othercars + localStorage.getItem("car02") + ',';
            if (localStorage.getItem("car04") != null) {
                othercars = othercars + localStorage.getItem("car04") + ',';
            }
        }
    }
    localStorage.setItem("tempGarage", othercars);
    localStorage.setItem("selectedCar", car);
}

function forthcar() {
    var car = localStorage.getItem("car04");
    var othercars = "";
    if (localStorage.getItem("car01") != null) {
        othercars = localStorage.getItem("car01") + ',';
        if (localStorage.getItem("car02") != null) {
            othercars = othercars + localStorage.getItem("car02") + ',';
            if (localStorage.getItem("car03") != null) {
                othercars = othercars + localStorage.getItem("car03") + ',';
            }
        }
    }
    localStorage.setItem("tempGarage", othercars);
    localStorage.setItem("selectedCar", car);
    /* localStorage.removeItem("selectedCar");
    var mycars = localStorage.getItem("garage");
    var car;
    // removes car 1-3
    var i;
    for (i = 0; i < 3; i++) {
        mycars = mycars.substring(0, mycars.indexOf('}') + 2);
    }
    car = mycars.substring(0, mycars.indexOf('}') + 1);
    localStorage.setItem("selectedCar", car); */
}

function signed() {
    localStorage.clear();
    var un = document.getElementById("username").value;
    localStorage.setItem("carid", 1);
    localStorage.setItem("garage", "");
    localStorage.setItem("uname", un);
}

function mycr() {
    var cardetails = JSON.parse(localStorage.getItem("selectedCar"));
    currmiles = parseInt(cardetails.mileage);

    document.getElementById("bra").innerHTML = cardetails.brand;
    document.getElementById("mod").innerHTML = cardetails.model;
    document.getElementById("yea").innerHTML = cardetails.year;
    document.getElementById("col").innerHTML = cardetails.color;
    document.getElementById("lice").innerHTML = cardetails.license;
    document.getElementById("mil").innerHTML = currmiles;

    document.getElementById("oil").innerHTML = (parseInt(cardetails.oil) + 5000) - currmiles;
    document.getElementById("oilf").innerHTML = (parseInt(cardetails.oilFilter) + 10000) - currmiles;
    document.getElementById("tir").innerHTML = (parseInt(cardetails.tire) + 7000) - currmiles;
    document.getElementById("cair").innerHTML = (parseInt(cardetails.cabinair) + 20000) - currmiles;
    document.getElementById("eair").innerHTML = (parseInt(cardetails.engineair) + 30000) - currmiles;
    document.getElementById("cof").innerHTML = (parseInt(cardetails.coolant) + 30000) - currmiles;
}

function loadupcar() {
    var cardets = JSON.parse(localStorage.getItem("selectedCar"));

    document.getElementById("bran").innerHTML = cardets.brand;
    document.getElementById("mode").innerHTML = cardets.model;
    document.getElementById("ya").innerHTML = cardets.year;
    document.getElementById("colo").value = cardets.color;
    document.getElementById("licen").value = cardets.license;
    document.getElementById("ml").value = parseInt(cardets.mileage);

    document.getElementById("olc").value = parseInt(cardets.oil);
    document.getElementById("oilfi").value = parseInt(cardets.oilFilter);
    document.getElementById("trc").value = parseInt(cardets.tire);
    document.getElementById("cairf").value = parseInt(cardets.cabinair);
    document.getElementById("eairf").value = parseInt(cardets.engineair);
    document.getElementById("cofl").value = parseInt(cardets.coolant);
}

function updatCar() {
    var cardets = JSON.parse(localStorage.getItem("selectedCar"));
    var upcr = "";
    // add code to make sure none are empty before saving
    upcr = '{"id": "' + cardets.id +
        '", "brand": "' + document.getElementById("bran").innerHTML +
        '", "model": "' + document.getElementById("mode").innerHTML +
        '", "year": "' + document.getElementById("ya").innerHTML +
        '", "color": "' + document.getElementById("colo").value +
        '", "license": "' + document.getElementById("licen").value +
        '", "mileage": "' + document.getElementById("ml").value +
        '", "oil": "' + document.getElementById("olc").value +
        '", "oilFilter": "' + document.getElementById("oilfi").value +
        '", "tire": "' + document.getElementById("trc").value +
        '", "cabinair": "' + document.getElementById("cairf").value +
        '", "engineair": "' + document.getElementById("eairf").value +
        '", "coolant": "' + document.getElementById("cofl").value +
        '"}';
    localStorage.setItem("selectedCar", upcr);

    //update garage to be correct
    // load temp for other cars and then add new car to garage that way commas already in there and new one added to the end of file for the forth car
    var newGarage = upcr;
    // check to see if tempgarage has a value
    var c = localStorage.getItem("tempGarage");
    if (c != "")
    {
        newGarage = c + upcr;
    }
    else {
        newGarage = upcr;
    }
    
    localStorage.setItem("garage", newGarage);
    document.getElementById("test").innerHTML = newGarage;
}

function blutoothupdatCar() {
    var cardets = JSON.parse(localStorage.getItem("selectedCar"));
    var upcr = "";
    var m = parseInt(document.getElementById("ml").value) *1.1;
    // add code to make sure none are empty before saving
    upcr = '{"id": "' + cardets.id +
        '", "brand": "' + document.getElementById("bran").innerHTML +
        '", "model": "' + document.getElementById("mode").innerHTML +
        '", "year": "' + document.getElementById("ya").innerHTML +
        '", "color": "' + document.getElementById("colo").value +
        '", "license": "' + document.getElementById("licen").value +
        '", "mileage": "' + m +
        '", "oil": "' + document.getElementById("olc").value +
        '", "oilFilter": "' + document.getElementById("oilfi").value +
        '", "tire": "' + document.getElementById("trc").value +
        '", "cabinair": "' + document.getElementById("cairf").value +
        '", "engineair": "' + document.getElementById("eairf").value +
        '", "coolant": "' + document.getElementById("cofl").value +
        '"}';
    localStorage.setItem("selectedCar", upcr);

    //update garage to be correct
    // load temp for other cars and then add new car to garage that way commas already in there and new one added to the end of file for the forth car
    var newGarage = upcr;
    // check to see if tempgarage has a value
    var c = localStorage.getItem("tempGarage");
    if (c != "") {
        newGarage = c + upcr;
    }
    else {
        newGarage = upcr;
    }

    localStorage.setItem("garage", newGarage);
    location.reload();
}

function loaddelete() {
    document.getElementById("del1").style.visibility = 'hidden';
    document.getElementById("del2").style.visibility = 'hidden';
    document.getElementById("del3").style.visibility = 'hidden';
    document.getElementById("del4").style.visibility = 'hidden';
    var cars = localStorage.getItem("garage");

    if (cars == "") {
        document.getElementById("nocar").innerHTML = "There are no Cars to delete";

    }
    else {
        var mycars = localStorage.getItem("garage");
        var car1, car2, car3, car4;
        car1 = mycars.substring(0, mycars.indexOf('}') + 1);
        localStorage.setItem("car01", car1);
        car1 = JSON.parse(car1);
        document.getElementById("carfid").innerHTML = car1.year + ' - ' + car1.brand + ' ' + car1.model + ' - ' + car1.license + '   ';
        mycars = mycars.substring(mycars.indexOf('}') + 2);
        document.getElementById("del1").style.visibility = 'visible';
        if (mycars != "") {
            car2 = mycars.substring(0, mycars.indexOf('}') + 1);
            localStorage.setItem("car02", car2);
            car2 = JSON.parse(car2);
            document.getElementById("carsed").innerHTML = car2.year + ' - ' + car2.brand + ' ' + car2.model + ' - ' + car2.license + '   ';
            mycars = mycars.substring(mycars.indexOf('}') + 2);
            document.getElementById("del2").style.visibility = 'visible';
            if (mycars != "") {
                car3 = mycars.substring(0, mycars.indexOf('}') + 1);
                localStorage.setItem("car03", car3);
                car3 = JSON.parse(car3);
                document.getElementById("carthd").innerHTML = car3.year + ' - ' + car3.brand + ' ' + car3.model + ' - ' + car3.license + '   ';
                mycars = mycars.substring(mycars.indexOf('}') + 2);
                document.getElementById("del3").style.visibility = 'visible';
                if (mycars != "") {
                    car4 = mycars.substring(0, mycars.indexOf('}') + 1);
                    localStorage.setItem("car04", car4);
                    car4 = JSON.parse(car4);
                    document.getElementById("carfod").innerHTML = car4.year + ' - ' + car4.brand + ' ' + car4.model + ' - ' + car4.license + '   ';
                    document.getElementById("del4").style.visibility = 'visible';
                }

            }
        }
    }
}

function deletecar1(){
    var othercars = "";
    //set other cars with if statement repeatedly checking if car0x has a value or not and then load the temp garage appropriately
    if (localStorage.getItem("car02") != null) {
        othercars = localStorage.getItem("car02") + ',';
        if (localStorage.getItem("car03") != null) {
            othercars = othercars + localStorage.getItem("car03") + ',';
            if (localStorage.getItem("car04") != null) {
                othercars = othercars + localStorage.getItem("car04") + ',';
            }
        }
    }
    localStorage.setItem("garage", othercars);
    localStorage.removeItem("car01");
    localStorage.removeItem("car02");
    localStorage.removeItem("car03");
    localStorage.removeItem("car04");
    location.reload();
}

function deletecar2() {
    var othercars = "";
    //set other cars with if statement repeatedly checking if car0x has a value or not and then load the temp garage appropriately
    if (localStorage.getItem("car01") != null) {
        othercars = localStorage.getItem("car01") + ',';
        if (localStorage.getItem("car03") != null) {
            othercars = othercars + localStorage.getItem("car03") + ',';
            if (localStorage.getItem("car04") != null) {
                othercars = othercars + localStorage.getItem("car04") + ',';
            }
        }
    }
    localStorage.setItem("garage", othercars);
    localStorage.removeItem("car01");
    localStorage.removeItem("car02");
    localStorage.removeItem("car03");
    localStorage.removeItem("car04");
    location.reload();
}

function deletecar3() {
    var othercars = "";
    //set other cars with if statement repeatedly checking if car0x has a value or not and then load the temp garage appropriately
    if (localStorage.getItem("car01") != null) {
        othercars = localStorage.getItem("car01") + ',';
        if (localStorage.getItem("car02") != null) {
            othercars = othercars + localStorage.getItem("car02") + ',';
            if (localStorage.getItem("car04") != null) {
                othercars = othercars + localStorage.getItem("car04") + ',';
            }
        }
    }
    localStorage.setItem("garage", othercars);
    localStorage.removeItem("car01");
    localStorage.removeItem("car02");
    localStorage.removeItem("car03");
    localStorage.removeItem("car04");
    location.reload();
}

function deletecar4() {
    var othercars = "";
    //set other cars with if statement repeatedly checking if car0x has a value or not and then load the temp garage appropriately
    if (localStorage.getItem("car01") != null) {
        othercars = localStorage.getItem("car01") + ',';
        if (localStorage.getItem("car02") != null) {
            othercars = othercars + localStorage.getItem("car02") + ',';
            if (localStorage.getItem("car03") != null) {
                othercars = othercars + localStorage.getItem("car03") + ',';
            }
        }
    }
    localStorage.setItem("garage", othercars);
    localStorage.removeItem("car01");
    localStorage.removeItem("car02");
    localStorage.removeItem("car03");
    localStorage.removeItem("car04");
    location.reload();
}