﻿function getun() {
    var usnm = localStorage.getItem("uname");
    document.getElementById("usna").innerHTML = usnm;
}

function createn() {
    var passw, repassw, nun;
    passw = document.getElementById("pass").value;
    repassw = document.getElementById("repass").value;
    nun = document.getElementById("cun").value;
    if (passw == repassw) {
        localStorage.setItem("uname", nun);
    }
    else 
        return alert("Passwords don't match.");
}

function deletecar() {
    localStorage.setItem("carid", 1);
    localStorage.setItem("garage", "");
}