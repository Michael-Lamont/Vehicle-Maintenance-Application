﻿function createOption(value) {
    model = document.createElement('option');
    model.value = value;
    model.innerHTML = value;
    model.id = value;

    document.getElementById('select').appendChild(model);
}

document.getElementById('sbrand').addEventListener('click', function () {
    document.getElementById('sbrand').value = 'acura';

    createOption('ILX');
    createOption('MDX');
    createOption('NSX');
    createOption('RDX');
    createOption('RLX');
    createOption('TLX');
});

document.getElementById('sbrand').addEventListener('click', function () {
    document.getElementById('sbrand').value = 'alfa-romeo';

    createOption('4C');
    createOption('Giulia');
    createOption('Giulia Quadrifoglio');
    createOption('Stelvio');
    createOption('Stelvio Quadrifoglio');

});

document.getElementById('sbrand').addEventListener('click', function () {
    document.getElementById('sbrand').value = 'audi';

    createOption('A3');
    createOption('A3 Sportback e-tron');
    createOption('A4');
    createOption('A4 Allroad Quattro');
    createOption('A5');
    createOption('A5 Sportback');
    createOption('A6');
    createOption('A7');
    createOption('A8');
    createOption('e-tron');
    createOption('e-tron GT');
    createOption('Q3');
    createOption('Q5');
    createOption('Q7');
    createOption('Q8');
    createOption('R8');
    createOption('RS3');
    createOption('RS5');
    createOption('RS5 Sportback');
    createOption('RS7');
    createOption('S3');
    createOption('S4');
    createOption('S5');
    createOption('S5 Sportback');
    createOption('S6');
    createOption('S7');
    createOption('S8');
    createOption('SQ5');
    createOption('TT / TTS');
    createOption('TT RS');
});